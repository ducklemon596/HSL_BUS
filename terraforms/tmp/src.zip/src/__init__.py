# Spark service package initializer
